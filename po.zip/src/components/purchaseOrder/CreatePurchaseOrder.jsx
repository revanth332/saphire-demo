import React, { useState, useEffect, useRef, useCallback } from "react";
import BotIconSVG from "./bot-icon.svg";
import UserIconSVG from "./user-icon.svg";
import { Mic } from "lucide-react";
import GeneratedPO from "./GeneratedPO.png";

// Simple icons
const BotIcon = () => (
  <span style={{ marginRight: "8px", fontSize: "1.5em" }}>
    <img alt="bot icon" className="h-8 w-8" src={BotIconSVG} />
  </span>
);
const UserIcon = () => (
  <span style={{ marginLeft: "8px", fontSize: "1.5em" }}>
    <img alt="user icon" className="h-8 w-8" src={UserIconSVG} />
  </span>
);
const DocumentIcon = () => (
  <span style={{ marginRight: "10px", fontSize: "2em", color: "#555" }}>
    📄
  </span>
);
const SendIcon = () => <span style={{ marginRight: "5px" }}>➢</span>;
const MicrophoneIcon = () => (
  <span style={{ fontSize: "1.2em", marginRight: "5px" }}></span>
);

const POGenerationScreen = ({
  vendorName = "Miracle Chemicals",
  vendorEmail = "procure@micchecmicals.com",
}) => {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");
  const [poPreviewContent, setPoPreviewContent] = useState(null);
  const [isBotTyping, setIsBotTyping] = useState(false);
  const chatMessagesEndRef = useRef(null);
  const inputRef = useRef(null); // Added ref for the text input

  const [conversationStage, setConversationStage] = useState(0);
  const [poDetails, setPoDetails] = useState({
    item: "",
    vendor: "",
    deliveryAddress: "",
    quantity: "",
    price: "",
    parsedItem: "",
  });

  const [isListening, setIsListening] = useState(false);
  const [speechError, setSpeechError] = useState(null);
  const [speechSupported, setSpeechSupported] = useState(true);
  const speechRecognitionRef = useRef(null);

  const scrollToBottom = () => {
    chatMessagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    setMessages([
      {
        id: Date.now(),
        text: "Welcome to the MiraAI Voice Agent for PO Creation - let's get started",
        sender: "bot",
      },
    ]);
    setConversationStage(0);
    setPoDetails({
      item: "",
      vendor: "",
      deliveryAddress: "",
      quantity: "",
      price: "",
      parsedItem: "",
    });
    setPoPreviewContent(null);
  }, []);

  const simulateBotResponse = useCallback(
    (userMessageText) => {
      setIsBotTyping(true);
      let botResponses = [];
      let newPoContent = undefined;
      let nextStage = conversationStage;
      let updatedPoDetails = { ...poDetails };

      const addBotMessage = (text, delay = 0) => {
        botResponses.push({ text, delay });
      };

      const capitalizeFirst = (str) =>
        str ? str.charAt(0).toUpperCase() + str.slice(1) : "";

      switch (conversationStage) {
        case 0: {
          const poRequestMatch = userMessageText
            .toLowerCase()
            .match(
              /need to create a purchase order for (?:some )?(.*?) from (.*?)(?:\.|$| po$)/i
            );
          if (poRequestMatch) {
            let itemText = poRequestMatch[1].trim();
            let vendorText = poRequestMatch[2].trim();

            updatedPoDetails.item = itemText;
            if (
              vendorText.toLowerCase().startsWith("miracle checmicals") ||
              vendorText.toLowerCase().startsWith("miracle chemicals")
            ) {
              updatedPoDetails.vendor = "Miracle Chemicals";
            } else {
              updatedPoDetails.vendor = vendorText;
            }

            addBotMessage(
              "Sure, let me get the supplier information - give me a moment please."
            );
            addBotMessage(
              `I was able to locate ${updatedPoDetails.vendor} based in Michigan. I added their supplier information in SAP to the PO.`,
              2500
            );
            addBotMessage(
              "What would you like for the delivery address to be?",
              2500
            );
            nextStage = 1;
          } else {
            addBotMessage(
              "I'm not sure how to start. Try saying: 'I need to create a PO for [item] from [vendor]'."
            );
          }
          break;
        }

        case 1:
          updatedPoDetails.deliveryAddress = userMessageText;
          addBotMessage(
            `Sure, marked this for delivery to ${userMessageText}.`,
            1200
          );

          if (
            updatedPoDetails.item.toLowerCase().includes("hypochlorite") &&
            !updatedPoDetails.item.toLowerCase().includes("sodium hypochlorite")
          ) {
            addBotMessage(
              `You mentioned ${capitalizeFirst(
                updatedPoDetails.item
              )} - were you referring to Sodium Hypochlorite?`,
              1200
            );
            nextStage = 2;
          } else {
            updatedPoDetails.parsedItem = updatedPoDetails.item;
            addBotMessage("Alright, how many do we need to order?", 1200);
            nextStage = 3;
          }
          break;

        case 2:
          if (userMessageText.toLowerCase().match(/^(yes|yeah|yep)/i)) {
            updatedPoDetails.parsedItem = "Sodium Hypochlorite";
            addBotMessage("Alright, how many do we need to order?", 1400);
            nextStage = 3;
          } else if (userMessageText.toLowerCase().match(/^(no|nope)/i)) {
            addBotMessage(
              `Okay, you didn't want Sodium Hypochlorite. What item was it then? (Currently using: ${capitalizeFirst(
                updatedPoDetails.item
              )})`,2200
            );
            addBotMessage("Alright, how many do we need to order?", 1400);
            updatedPoDetails.parsedItem = updatedPoDetails.item;
            nextStage = 3;
          } else {
            addBotMessage(
              "Okay. Let's assume Sodium Hypochlorite for now. How many do we need to order?",
              1400
            );
            updatedPoDetails.parsedItem = "Sodium Hypochlorite";
            nextStage = 3;
          }
          break;

        case 3: {
          const quantityMatch = userMessageText.match(
            /(\d+[\s\w]*gallon[s]?)/i
          );
          if (quantityMatch) {
            updatedPoDetails.quantity = quantityMatch[1];
            updatedPoDetails.price = "$1.25 per gallon";
            addBotMessage(
              `I see that they were priced at ${updatedPoDetails.price} in our last order with ${updatedPoDetails.vendor}. Is that the correct price for this PO?`,2200
            );
            nextStage = 4;
          } else {
            addBotMessage(
              "I didn't catch the quantity in gallons. How many gallons do we need?",1200
            );
          }
          break;
        }

        case 4:
          if (userMessageText.toLowerCase().match(/^(yes|yeah|yep|correct)/i)) {
            addBotMessage(
              "Perfect, I've added all the details. Shall I submit to the supplier via SAP?",
              1500
            );
            nextStage = 5;
          } else {
            addBotMessage(
              "Okay, what should the price be? Or you can tell me to adjust other details.",2000
            );
          }
          break;

        case 5:
          if (
            userMessageText
              .toLowerCase()
              .match(/^(yes|yeah|yep|please do|go ahead)/i)
          ) {
            addBotMessage("Generating PO...", 1500);

            newPoContent = `
## Purchase Order Draft ##

**Vendor:** ${updatedPoDetails.vendor}
**Contact:** ${vendorEmail} 
**Date:** ${new Date().toLocaleDateString()}

**Delivery Address:** ${updatedPoDetails.deliveryAddress}

**Items Requested:**
- Item: ${capitalizeFirst(updatedPoDetails.parsedItem || updatedPoDetails.item)}
- Quantity: ${updatedPoDetails.quantity}
- Price: ${updatedPoDetails.price}
- Total: (Calculation can be added if values are numeric)

**Notes:**
- Please verify all details before sending.
- This PO was generated via MiraAI Voice Agent.

---
*This is a simulated PO generated by the assistant.*
        `;
            addBotMessage(
              `Okay, I've drafted the PO. Please review the details on the right. You can then click "Send PO".`,
              1500
            );
            nextStage = 6;
          } else {
            addBotMessage(
              "Okay, let me know when you're ready to submit, or if you want to make changes."
            );
          }
          break;

        case 6:
          if (userMessageText.toLowerCase().match(/new po|start over|reset/i)) {
            addBotMessage(
              "Alright, let's start a new Purchase Order. What would you like to order?"
            );
            updatedPoDetails = {
              item: "",
              vendor: "",
              deliveryAddress: "",
              quantity: "",
              price: "",
              parsedItem: "",
            };
            newPoContent = null;
            nextStage = 0;
          } else {
            addBotMessage(
              "The PO is ready on the right. You can click 'Send PO' or say 'new po' to start another one."
            );
          }
          break;

        default:
          addBotMessage(
            "I'm a bit lost. Let's try starting over. Tell me what you'd like to order."
          );
          updatedPoDetails = {
            item: "",
            vendor: "",
            deliveryAddress: "",
            quantity: "",
            price: "",
            parsedItem: "",
          };
          newPoContent = null;
          nextStage = 0;
      }

      let cumulativeDelay = 300;
      if (botResponses.length === 0 && conversationStage !== nextStage) {
      }

      botResponses.forEach((response, index) => {
        setTimeout(() => {
          setMessages((prevMessages) => [
            ...prevMessages,
            {
              id: Date.now() + Math.random() + index,
              text: response.text,
              sender: "bot",
            },
          ]);
          if (index === botResponses.length - 1 && newPoContent !== undefined) {
            setPoPreviewContent(newPoContent);
          }
        }, cumulativeDelay);
        cumulativeDelay += (response.delay || 1200) + Math.random() * 500;
      });

      setTimeout(() => {
        setIsBotTyping(false);
        setConversationStage(nextStage);
        setPoDetails(updatedPoDetails);
        if (botResponses.length === 0 && newPoContent !== undefined) {
          setPoPreviewContent(newPoContent);
        }
      }, cumulativeDelay);
    },
    [
      conversationStage,
      poDetails,
      vendorEmail,
      setIsBotTyping,
      setMessages,
      setPoPreviewContent,
      setConversationStage,
      setPoDetails,
    ]
  );

  // Setup Speech Recognition
  useEffect(() => {
    const SpeechRecognitionAPI =
      window.SpeechRecognition || window.webkitSpeechRecognition;

    if (!SpeechRecognitionAPI) {
      console.warn("Speech Recognition API not supported in this browser.");
      setSpeechError("Speech recognition is not supported by your browser.");
      setSpeechSupported(false);
      return;
    }

    const recognition = new SpeechRecognitionAPI();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      setIsListening(true);
      setSpeechError(null);
    };

    recognition.onend = () => {
      setIsListening(false);
      // Optionally, ensure focus on input if it's not already focused by onresult
      // if (inputRef.current && document.activeElement !== inputRef.current) {
      //   inputRef.current.focus();
      // }
    };

    recognition.onerror = (event) => {
      console.error("Speech recognition error:", event.error);
      let errorMessage = `Speech error: ${event.error}`;
      if (event.error === "no-speech") {
        errorMessage = "No speech was detected. Please try speaking again.";
      } else if (event.error === "audio-capture") {
        errorMessage =
          "Microphone problem. Ensure it's connected and permissions are granted.";
      } else if (event.error === "not-allowed") {
        errorMessage =
          "Microphone access denied. Please enable it in browser settings.";
      }
      setSpeechError(errorMessage);
      setIsListening(false);
    };

    // MODIFIED: onresult now populates inputValue and focuses the input field
    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setInputValue(transcript); // Set the transcript to the input field
      if (inputRef.current) {
        inputRef.current.focus(); // Focus the input field for potential editing
      }
      // Note: We no longer add to messages or call simulateBotResponse here.
      // The user will press Send or Enter.
    };

    speechRecognitionRef.current = recognition;

    return () => {
      if (speechRecognitionRef.current) {
        speechRecognitionRef.current.onstart = null;
        speechRecognitionRef.current.onend = null;
        speechRecognitionRef.current.onerror = null;
        speechRecognitionRef.current.onresult = null;
        speechRecognitionRef.current.stop();
      }
    };
    // Dependencies updated: simulateBotResponse and setMessages removed as they are no longer directly used by onresult.
    // Added setInputValue. All listed dependencies are stable state setters.
  }, [setInputValue, setIsListening, setSpeechError, setSpeechSupported]);

  const handleInputChange = (e) => {
    setInputValue(e.target.value);
  };

  const handleSendMessage = useCallback(() => {
    if (inputValue.trim() === "") return;

    const newUserMessage = {
      id: Date.now(),
      text: inputValue,
      sender: "user",
    };
    setMessages((prevMessages) => [...prevMessages, newUserMessage]);
    simulateBotResponse(inputValue);
    setInputValue("");
  }, [inputValue, simulateBotResponse, setMessages, setInputValue]);

  const handleSendPo = () => {
    if (poPreviewContent) {
      alert(
        `Purchase Order for ${
          poDetails.vendor || vendorName
        } would be sent now!\n\nContent:\n${poPreviewContent}`
      );
      setMessages((prev) => [
        ...prev,
        {
          id: Date.now(),
          text: "Purchase Order has been sent!",
          sender: "bot",
          type: "success",
        },
      ]);
      setPoPreviewContent(null);
      setPoDetails({
        item: "",
        vendor: "",
        deliveryAddress: "",
        quantity: "",
        price: "",
        parsedItem: "",
      });
      setConversationStage(0);
      setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          {
            id: Date.now() + 1,
            text: "You can now create a new Purchase Order. What would you like to order?",
            sender: "bot",
          },
        ]);
      }, 500);
    } else {
      alert("No PO to send. Please generate one using the chat first.");
    }
  };

  const handleToggleListening = useCallback(() => {
    if (!speechRecognitionRef.current || !speechSupported) {
      setSpeechError("Speech recognition is not available or not supported.");
      return;
    }

    if (isListening) {
      speechRecognitionRef.current.stop();
    } else {
      try {
        setInputValue(""); // Clear input field before starting new speech input
        setSpeechError(null);
        speechRecognitionRef.current.start();
      } catch (e) {
        console.error("Error starting speech recognition:", e);
        setSpeechError(
          "Could not start listening. Please try again or check microphone permissions."
        );
        setIsListening(false);
      }
    }
  }, [
    isListening,
    speechSupported,
    setInputValue,
    setIsListening,
    setSpeechError,
  ]); // Added setInputValue to deps for clearing

  const styles = {
    pageContainer: {
      display: "flex",
      flexDirection: "column",
      fontFamily: "Arial, sans-serif",
      height: "100vh",
      margin: "0 auto",
      border: "1px solid #ccc",
      boxShadow: "0 0 10px rgba(0,0,0,0.1)",
      overflow: "hidden",
    },
    header: { padding: "20px", borderBottom: "1px solid #e0e0e0" },
    mainTitle: { fontSize: "24px", fontWeight: "bold", marginBottom: "5px" },
    subTitle: { fontSize: "14px", color: "#555", marginBottom: "10px" },
    vendorInfo: { fontSize: "12px", color: "#777" },
    contentArea: { display: "flex", flex: 1, overflow: "hidden" },
    chatPane: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      borderRight: "1px solid #e0e0e0",
      backgroundColor: "#f9f9f9",
    },
    chatHeader: {
      backgroundColor: "#004A7F",
      color: "white",
      padding: "15px",
      fontSize: "16px",
      fontWeight: "bold",
      display: "flex",
      alignItems: "center",
    },
    chatMessages: {
      flex: 1,
      padding: "15px",
      overflowY: "auto",
      display: "flex",
      flexDirection: "column",
      gap: "10px",
    },
    messageBubble: {
      maxWidth: "75%",
      padding: "10px 15px",
      borderRadius: "18px",
      fontSize: "14px",
      lineHeight: "1.4",
      wordWrap: "break-word",
    },
    botMessage: {
      backgroundColor: "#e9e9eb",
      color: "#333",
      alignSelf: "flex-start",
      borderBottomLeftRadius: "4px",
    },
    userMessage: {
      backgroundColor: "#0078D4",
      color: "white",
      alignSelf: "flex-end",
      borderBottomRightRadius: "4px",
    },
    successMessage: {
      backgroundColor: "#e8f5e9",
      color: "#2e7d32",
      alignSelf: "flex-start",
      border: "1px solid #a5d6a7",
      borderBottomLeftRadius: "4px",
    },
    chatInputContainer: {
      padding: "10px 10px 0px 10px",
      borderTop: "1px solid #e0e0e0",
      backgroundColor: "white",
    },
    speechErrorText: {
      color: "red",
      fontSize: "12px",
      textAlign: "center",
      marginBottom: "8px",
      minHeight: "16px",
    },
    chatInputArea: {
      display: "flex",
      paddingBottom: "10px",
      alignItems: "center",
    },
    chatInput: {
      flex: 1,
      padding: "10px",
      border: "1px solid #ccc",
      borderRadius: "20px",
      marginRight: "10px",
      fontSize: "14px",
    },
    micButton: {
      padding: "10px 12px",
      border: "none",
      borderRadius: "20px",
      cursor: "pointer",
      fontSize: "14px",
      display: "flex",
      alignItems: "center",
      marginRight: "8px",
    },
    sendButton: {
      padding: "10px 15px",
      backgroundColor: "#0078D4",
      color: "white",
      border: "none",
      borderRadius: "20px",
      cursor: "pointer",
      fontSize: "14px",
      display: "flex",
      alignItems: "center",
    },
    previewPane: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      padding: "0",
      backgroundColor: "white",
    },
    previewHeader: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      padding: "20px",
      borderBottom: "1px solid #e0e0e0",
    },
    previewTitle: { fontSize: "18px", fontWeight: "bold" },
    sendPoButton: {
      padding: "10px 15px",
      backgroundColor: "#4CAF50",
      color: "white",
      border: "none",
      borderRadius: "5px",
      cursor: "pointer",
      fontSize: "14px",
      display: "flex",
      alignItems: "center",
    },
    previewContent: {
      flex: 1,
      padding: "20px",
      overflowY: "auto",
      fontSize: "14px",
      color: "#333",
    },
    previewPlaceholder: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      height: "100%",
      color: "#888",
      textAlign: "center",
    },
    typingIndicator: {
      fontSize: "12px",
      fontStyle: "italic",
      color: "#777",
      padding: "5px 15px",
      alignSelf: "flex-start",
    },
  };

  return (
    <div style={styles.pageContainer}>
      <div style={styles.header}>
        <div style={styles.mainTitle}>Generate PO</div>
        <div style={styles.subTitle}>
          Interact with the chatbot to generate Purchase Orders.
        </div>
        <div style={styles.vendorInfo}>
          Vendor Name: {poDetails.vendor || vendorName} | Vendor Email:{" "}
          {vendorEmail}
        </div>
      </div>
      <div style={styles.contentArea}>
        <div style={styles.chatPane}>
          <div style={styles.chatHeader}>
            <BotIcon /> MiraAI Assistant
          </div>
          <div style={styles.chatMessages}>
            {messages.map((msg) => (
              <div
                key={msg.id}
                style={{
                  ...styles.messageBubble,
                  ...(msg.sender === "bot"
                    ? styles.botMessage
                    : styles.userMessage),
                  ...(msg.type === "success" ? styles.successMessage : {}),
                  display: "flex",
                  alignItems: "center",
                }}
              >
                {msg.sender === "bot" && <BotIcon />}
                <span style={{ flex: 1 }}>{msg.text}</span>
                {msg.sender === "user" && <UserIcon />}
              </div>
            ))}
            {isBotTyping && (
              <div style={styles.typingIndicator}>Assistant is typing...</div>
            )}
            <div ref={chatMessagesEndRef} />
          </div>
          <div style={styles.chatInputContainer}>
            <div style={styles.speechErrorText}>
              {speechError && speechError}
            </div>
            <div style={styles.chatInputArea}>
              <button
                style={{
                  ...styles.micButton,
                  backgroundColor: isListening
                    ? "#FF6347"
                    : !speechSupported
                    ? "#cccccc"
                    : "#0078D4",
                  color: "white",
                  cursor:
                    !speechSupported || isBotTyping ? "not-allowed" : "pointer",
                }}
                onClick={handleToggleListening}
                disabled={isBotTyping || !speechSupported}
                title={
                  !speechSupported
                    ? "Speech recognition not supported"
                    : isListening
                    ? "Stop listening"
                    : "Start listening"
                }
              >
                <Mic /> {isListening ? "Listening..." : "Speak"}
              </button>
              <input
                ref={inputRef} // Attach the ref here
                type="text"
                style={styles.chatInput}
                value={inputValue}
                onChange={handleInputChange}
                onKeyPress={(e) =>
                  e.key === "Enter" &&
                  !isBotTyping &&
                  !isListening &&
                  handleSendMessage()
                }
                placeholder={
                  isListening
                    ? "Listening..."
                    : "Type your message or use the microphone..."
                }
                disabled={isBotTyping || isListening} // Input is disabled while listening
              />
              <button
                style={{
                  ...styles.sendButton,
                  opacity:
                    isBotTyping || isListening || inputValue.trim() === ""
                      ? 0.6
                      : 1,
                }}
                onClick={handleSendMessage}
                disabled={
                  isBotTyping || isListening || inputValue.trim() === ""
                }
              >
                <SendIcon /> Send
              </button>
            </div>
          </div>
        </div>
        <div style={styles.previewPane}>
          <div style={styles.previewHeader}>
            <div style={styles.previewTitle}>PO Preview</div>
            <button
              style={{
                ...styles.sendPoButton,
                opacity: !poPreviewContent ? 0.5 : 1,
              }}
              onClick={handleSendPo}
              disabled={!poPreviewContent}
            >
              <SendIcon /> Send PO
            </button>
          </div>
          <div style={styles.previewContent}>
            {poPreviewContent ? (
              <img src={GeneratedPO} />
            ) : (
              <div style={styles.previewPlaceholder}>
                <DocumentIcon />
                <div>
                  Purchase Order Preview will appear here after you complete the
                  conversation.
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default POGenerationScreen;
